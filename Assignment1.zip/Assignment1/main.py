# Lab Professor: Laily Ajellu
# Jacob Solano - 101348583
import copy
import re
from time import sleep
from tabulate import tabulate

# Employee ID, Employee Name, Employee Type, Years Worked, Total Purchased, Total Discount, Employee Discount Number]
employee_list = [
    [1001, "John Alber", "hourly", 8, 0, 0, 22737],
    [1002, "Sarah Rose", "manager", 12, 0, 0, 22344],
    [1003, "Alex Folen", "manager", 5, 0, 0, 22957],
    [1004, "Pola Sahari", "hourly", 17, 0, 0, 22488]
]

# Item Number, Item Name, Item Cost
item_list = [
    [11526, "Nike Shoes", 120],
    [11849, "Trampoline", 180],
    [11966, "Mercury Bicycle", 150],
    [11334, "Necklace Set", 80],
    [11337, "Zara Jacket", 900],
    [11338, "Testing Purposes", 900000]
]


# returns a list that contains all employee id
def check_employee_id_list(emp_list):
    return [x[0] for x in emp_list]


# returns a list that contains all employee discount number
def check_employee_discount_number_list(emp_list):
    return [x[6] for x in emp_list]


# returns a list that contains all item number
def check_item_number_list(i_list):
    return [x[0] for x in i_list]


# validates string input
def validate_string_input(prompt_message):
    while True:
        user_input = input(prompt_message)
        if user_input:
            if re.match("^[a-zA-Z ]*$", user_input):
                return user_input
            else:
                print("Please input only letters or spaces")
                continue
        else:
            print("Please enter your input. ")
            continue


# validates employee type input (user can only enter hourly or manager case-insensitive)
def validate_employee_type(prompt_message):
    while True:
        user_input = input(prompt_message)
        user_input = user_input.lower().strip()
        if user_input == "hourly" or user_input == "manager":
            return user_input
        else:
            print("Please input only hourly or manager. ")
            continue


# validates integer input
def validate_int_input(prompt_message):
    while True:
        try:
            user_input = int(input(prompt_message))
            return user_input
        except ValueError:
            print("Please input a valid integer number.")
            continue


# checks if the employee id, employee discount number, or item number is unique
def check_unique(prompt_message, unique_list):
    while True:
        try:
            user_input = int(input(prompt_message))
        except ValueError:
            print("Please enter a valid integer number.")
            continue
        else:
            if user_input in unique_list:
                print("That id or discount number is already in the list.")
                continue
            else:
                return user_input


# add employee function
def add_employee():
    input("Creating an employee... (Press Enter)")
    employee_details = []

    prompt_message = "Enter employee id: "
    employee_id_list = check_employee_id_list(employee_list)
    employee_id = check_unique(prompt_message, employee_id_list)

    prompt_message = "Enter employee name: "
    employee_name = validate_string_input(prompt_message)

    prompt_message = "Enter employee type: "
    employee_type = validate_employee_type(prompt_message)

    prompt_message = "Enter number of years worked: "
    employee_years_worked = validate_int_input(prompt_message)

    prompt_message = "Enter employee discount number: "
    employee_discount_number_list = check_employee_discount_number_list(employee_list)
    employee_discount_number = check_unique(prompt_message, employee_discount_number_list)

    employee_details.append(employee_id)
    employee_details.append(employee_name)
    employee_details.append(employee_type)
    employee_details.append(employee_years_worked)
    employee_details.append(0)
    employee_details.append(0)
    employee_details.append(employee_discount_number)

    employee_list.append(employee_details)
    input("Successfully added employee. (Press Enter)")

    prompt_message = "Add another employee? Type Yes or No: "
    choice = confirm_yes_or_no(prompt_message)
    if choice == "yes":
        add_employee()
    else:
        prompt_message = "Go to menu? Type Yes or No: "
        choice = confirm_yes_or_no(prompt_message)
        if choice == "yes":
            print("Going to main menu...")
            sleep(1)
            menu()
        else:
            print("Thank you for using this application. Good bye")
            quit()


def add_item():
    input("Creating an item... (Press Enter)")
    item_details = []

    prompt_message = "Enter item id: "
    item_id_list = check_item_number_list(item_list)
    item_id = check_unique(prompt_message, item_id_list)

    prompt_message = "Enter item name: "
    item_name = validate_string_input(prompt_message)

    prompt_message = "Enter item cost: "
    item_cost = validate_int_input(prompt_message)

    item_details.append(item_id)
    item_details.append(item_name)
    item_details.append(item_cost)
    item_list.append(item_details)
    show_item_list()

    input("Successfully added item. (Press Enter)")

    prompt_message = "Add another item? Type Yes or No: "
    choice = confirm_yes_or_no(prompt_message)
    if choice == "yes":
        add_item()
    else:
        prompt_message = "Go to menu? Type Yes or No: "
        choice = confirm_yes_or_no(prompt_message)
        if choice == "yes":
            going_to_menu()
        else:
            print("Thank you for using this application. Good bye")
            quit()


# prints all elements in the item_list in table format
def show_item_list():
    print("Item Number, Item Name, Item Cost ")
    for x in item_list:
        for i in x:
            if x.index(i) == 2:
                print("${:,.2f}".format(i))
            else:
                print(i, end=", ")


# prints all elements in the employee_list in table format
def show_employee_list():
    for x in employee_list:
        for i in x:
            if x.index(i) == 4 or x.index(i) == 5:
                print("${:,.2f}".format(i), end=", ")
            if x.index(i) == 6:
                print(i)
            else:
                print(i, end=", ")

    prompt_message = "Go to menu? Type Yes or No: "
    choice = confirm_yes_or_no(prompt_message)
    if choice == "yes":
        going_to_menu()
    else:
        print("Thank you for using this application. Good bye")
        quit()


# validates yes or no input
def confirm_yes_or_no(prompt_message):
    while True:
        user_input = input(prompt_message)
        user_input = user_input.lower()
        if user_input:
            if re.match("^(?:yes|no)$", user_input):
                return user_input
            else:
                print("Please input only Yes or No")
                continue
        else:
            print("Please enter your input. ")
            continue


# checks if the employee discount number or item number is unique
def check_unique_for_purchase(prompt_message, unique_list, number_type):
    while True:
        try:
            user_input = int(input(prompt_message))
        except ValueError:
            print("Please enter a valid integer number.")
            continue
        else:
            if user_input in unique_list:
                return user_input
            else:
                print(f"That {number_type} does not exist.")
                continue


# make a purchase function
def make_a_purchase():
    input("Making a purchase... (Press Enter)")
    show_item_list()

    prompt_message = "Enter employee discount number: "
    employee_discount_number_list = check_employee_discount_number_list(employee_list)
    number_type = "employee discount number"
    employee_discount_number = check_unique_for_purchase(prompt_message, employee_discount_number_list, number_type)

    prompt_message = "Enter item number: "
    item_number_list = check_item_number_list(item_list)
    number_type = "item number"
    item_number = check_unique_for_purchase(prompt_message, item_number_list, number_type)

    prompt_message = "Confirm purchase? Type Yes or No: "
    choice = confirm_yes_or_no(prompt_message)
    if choice == "yes":
        # retrieves item price
        for i, x in enumerate(item_list):
            if item_number in x:
                j = x.index(item_number)  # j is 0
                item_price = item_list[i][j + 2]  # adds 2 since item price is located at index 2

        # retrieves years worked and employee type
        for i, x in enumerate(employee_list):
            if employee_discount_number in x:
                j = x.index(employee_discount_number)  # j is 6
                years_worked = employee_list[i][j - 3]  # subtracts 3 since years worked is located at index 3
                employee_type = employee_list[i][j - 4]  # subtracts 4 since employee type is located at index 2

        # Calculate discount
        discount_percentage_by_years = min(0.10, 0.02 * years_worked)
        if employee_type == "hourly":
            discount_percentage_by_employee_type = 0.02
        else:
            discount_percentage_by_employee_type = 0.10

        total_percentage_discount = discount_percentage_by_years + discount_percentage_by_employee_type
        purchase_discount = min(200, item_price * total_percentage_discount)

        for i, x in enumerate(employee_list):
            if employee_discount_number in x:
                j = x.index(employee_discount_number)  # j is 6
                foo_employee_total_discount = employee_list[i][j - 1]
                foo_employee_total_discount += purchase_discount
                if foo_employee_total_discount > 200:
                    purchase_discount = 200 - purchase_discount
                if employee_list[i][j - 1] == 200:
                    employee_list[i][j - 2] += item_price  # updates total purchased
                    employee_list[i][j - 1] = min(200,
                                                  employee_list[i][j - 1] + purchase_discount)  # updates total discount
                else:
                    employee_list[i][j - 2] += item_price - purchase_discount  # updates total purchased
                    employee_list[i][j - 1] = min(200,
                                                  employee_list[i][j - 1] + purchase_discount)  # updates total discount

        input("Successfully purchased item. (Press Enter)")
        prompt_message = "Purchase another item? Type Yes or No: "
        choice = confirm_yes_or_no(prompt_message)
        if choice == "yes":
            make_a_purchase()
        else:
            show_employee_list()
            prompt_message = "Go to menu? Type Yes or No: "
            choice = confirm_yes_or_no(prompt_message)
            if choice == "yes":
                going_to_menu()
            else:
                print("Thank you for using this application. Good bye")
                quit()

    else:
        input("Item was not purchased. (Press Enter)")
        prompt_message = "Go to menu? Type Yes or No: "
        choice = confirm_yes_or_no(prompt_message)
        if choice == "yes":
            going_to_menu()
        else:
            print("Thank you for using this application. Good bye")
            quit()


# validates user input for menu
def validate_menu_choice(prompt_message):
    while True:
        user_input = input(prompt_message)
        if user_input:
            if re.match("^(?:1|2|3|4|5)$", user_input):
                return user_input
            else:
                print("Please input only 1 to 5")
                continue
        else:
            print("Please enter your input. ")
            continue


# menu function
def menu():
    print("--------------------------------------------------")
    print("| 1. Create Employee                             |")
    print("| 2. Create Item                                 |")
    print("| 3. Make Purchase                               |")
    print("| 4. All Employee Summary                        |")
    print("| 5. Exit                                        |")
    print("--------------------------------------------------")

    prompt_message = "Enter your choice: "
    choice = int(validate_menu_choice(prompt_message))
    if choice == 1:
        add_employee()
    elif choice == 2:
        add_item()
    elif choice == 3:
        make_a_purchase()
    elif choice == 4:
        show_employee_list()
    elif choice == 5:
        print("Thank you for using this application. Good bye")
        quit()


# going to menu function
def going_to_menu():
    print("Going to main menu...")
    sleep(1)
    menu()


print("Employee ID, Employee Name, Employee Type, Years Worked, Total Purchased, Total Discount, Employee Discount "
      "Number")

# formatted_item_list[i][2] = "${:,.2f}".format(formatted_item_list[i][2])
for x in employee_list:
    for i in x:
        if x.index(i) == 4 or x.index(i) == 5:
            print("${:,.2f}".format(i), end=", ")
        if x.index(i) == 6:
            print(i)
        else:
            print(i, end=", ")

print("")
show_item_list()
menu()
