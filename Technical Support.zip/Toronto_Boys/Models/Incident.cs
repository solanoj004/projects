﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Toronto_Boys.Models
{
    public class Incident
    {

        [Key]
        public int IncidentId { get; set; }
        [Required(ErrorMessage = "Please enter Incident Title")]
        public string? Title { get; set; }
        [DisplayName("Customer")]
        public int CustomerId { get; set; }
        
        public virtual Customer? Customer { get; set; }
        [DisplayName("Product")]
        public int ProductId { get; set; }
        public Product? Product { get; set; }
        [DisplayName("Technician")]
        [ForeignKey("Technician")]
        public int? TechnicianId { get; set; }
        public virtual Technician? Technician { get; set; }
        public string? Description { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM-dd-yyyy}", ApplyFormatInEditMode = true)]
        [DisplayName("Date Opended")]
        public DateTime DateOpened { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM-dd-yyyy}", ApplyFormatInEditMode = true)]
        [DisplayName("Date Closed")]
        public DateTime? DateClosed { get; set; }
        

    }
}
