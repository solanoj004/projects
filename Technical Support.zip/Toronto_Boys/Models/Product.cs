﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Toronto_Boys.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Please enter product code")]
        [DisplayName("Product Code")]
        public string? Code { get; set; }

        [Required(ErrorMessage = "Please enter product name")]
        [DisplayName("Product Name")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Please enter products yearly price")]
        [DisplayName("Yearly Price")]
        public double YearlyPrice { get; set; }

        [Required(ErrorMessage = "Please choose a release date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM-dd-yyyy}")]
        [DisplayName("Release Date")]
        public DateTime ReleaseDate { get; set; }
        public ICollection<CustomerProduct>? CustomerProduct { get; set; }

    }
}
