﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using static Toronto_Boys.Controllers.CustomerController;

namespace Toronto_Boys.Models
{
    public class Customer
    {
        [Key]
        public int CustomerID { get; set; }
        [DisplayName("First Name")]
        [Required(ErrorMessage = "Please enter Customers First Name")]
        [StringLength(50)]
        public string? FirstName { get; set; }
        [DisplayName("last Name")]
        [Required(ErrorMessage = "Please enter Customers Last Name")]
        [StringLength(50)]
        public string? LastName { get; set; }
        [Required(ErrorMessage = "Please enter Customers Address")]
        [StringLength(50)]
        public string? Address { get; set; }
        [Required(ErrorMessage = "Please enter Customers City")]
        [StringLength(50)]
        public string? City { get; set; }
        [Required(ErrorMessage = "Please enter Customers State")]
        [StringLength(50)]
        public string? State { get; set; }
        [DisplayName("Postal Code")]
        [Required(ErrorMessage = "Please enter Customers Postal Code")]
        [StringLength(50)]
        public string? PostalCode { get; set; }

        [Required]
        public int? CountryId { get; set; }
        [EmailAddress]
        public string? Email { get; set; }
        [RegularExpression(@"^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$", ErrorMessage = "Phone number must be in 999-999-9999 format")]
        public string? Phone { get; set; }
        public string? FullName { get { return FirstName + " " + LastName; } }
        public ICollection<CustomerProduct>? CustomerProduct { get; set; }
 
    }
}
