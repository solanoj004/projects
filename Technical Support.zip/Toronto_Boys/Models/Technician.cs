﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Toronto_Boys.Models
{
    public class Technician
    {
        [Key]
        public int TechnicianID { get; set; }

        [Required(ErrorMessage = "Please enter Technicians Name")]
        [DisplayName("Technician's Name")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Please enter Technicians Email")]
        [EmailAddress]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Please enter Technicians Phone")]
        [Phone]
        public string? Phone { get; set; }
    }
}
