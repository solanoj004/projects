﻿using Microsoft.EntityFrameworkCore;


namespace Toronto_Boys.Models
{
    public class MainContext: DbContext
    {
        public MainContext(DbContextOptions<MainContext> options)
            : base(options) { }

        public DbSet<Customer> Customer { get; set; }
        public DbSet<Product> Product { get; set; }
        public DbSet<Technician> Technician { get; set; }
        public DbSet<Incident> Incident { get; set; }

        public DbSet<CustomerProduct> CustomerProducts { get; set; }
 
        public DbSet<Country> Country { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Country>().HasData(
                new Country { CountryId = 1, Name = "Afghanistan" },
                new Country { CountryId = 2, Name = " Albania" },
                new Country { CountryId = 3, Name = " Algeria" },
                new Country { CountryId = 4, Name = " Andorra" },
                new Country { CountryId = 5, Name = " Angola" },
                new Country { CountryId = 6, Name = " Antigua & Deps" },
                new Country { CountryId = 7, Name = " Argentina" },
                new Country { CountryId = 8, Name = " Armenia" },
                new Country { CountryId = 9, Name = " Australia" },
                new Country { CountryId = 10, Name = " Austria" },
                new Country { CountryId = 11, Name = " Azerbaijan" },
                new Country { CountryId = 12, Name = " Bahamas" },
                new Country { CountryId = 13, Name = " Bahrain" },
                new Country { CountryId = 14, Name = " Bangladesh" },
                new Country { CountryId = 15, Name = " Barbados" },
                new Country { CountryId = 16, Name = " Belarus" },
                new Country { CountryId = 17, Name = " Belgium" },
                new Country { CountryId = 18, Name = " Belize" },
                new Country { CountryId = 19, Name = " Benin" },
                new Country { CountryId = 20, Name = " Bhutan" },
                new Country { CountryId = 21, Name = " Bolivia" },
                new Country { CountryId = 22, Name = " Bosnia Herzegovina" },
                new Country { CountryId = 23, Name = " Botswana" },
                new Country { CountryId = 24, Name = " Brazil" },
                new Country { CountryId = 25, Name = " Brunei" },
                new Country { CountryId = 26, Name = " Bulgaria" },
                new Country { CountryId = 27, Name = "Burkina" },
                new Country { CountryId = 28, Name = "Canada" },
                new Country { CountryId = 29, Name = "India" },
                new Country { CountryId = 30, Name = "Philippines" },
                new Country { CountryId = 31, Name = "USA" },
                new Country { CountryId = 32, Name = "Vietnam" });

            modelBuilder.Entity<Customer>().HasData(
                new Customer
                {
                    CustomerID = 1,
                    FirstName = "Ronak",
                    LastName = "Gala",
                    Address = "4029 Bathurst St",
                    City = "Toronto",
                    State = "Ontario",
                    PostalCode = "M2K 4A8",
                    CountryId = 1,
                    Email = "Ronak.Gala@georgebrown.ca",
                    Phone = "467-654-1234"
                },
                new Customer
                {
                    CustomerID = 2,
                    FirstName = "Danny",
                    LastName = "Nygen",
                    Address = "100 Beverly St",
                    City = "Toronto",
                    State = "Ontario",
                    PostalCode = "M25 4d8",
                    CountryId = 2,
                    Email = "Danny.Nygen@georgebrown.ca",
                    Phone = "616-214-1234"
                },
                new Customer
                {
                    CustomerID = 3,
                    FirstName = "Jacob",
                    LastName = "Solano",
                    Address = "15A Dixxe Road",
                    City = "Scarborough",
                    State = "Ontario",
                    PostalCode = "M16 3Bh",
                    CountryId = 3,
                    Email = "Jacob.Solano@georgebrown.ca",
                    Phone = "654-693-3258"
                }
                );
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductID = 101,
                    Code = "ABC123",
                    Name = "1v1 League Tourney",
                    YearlyPrice = 4.99,
                    ReleaseDate = new DateTime()
                },
                new Product
                {
                    ProductID = 102,
                    Code = "567SGV",
                    Name = "Team Manager 1.0",
                    YearlyPrice = 7.99,
                    ReleaseDate = new DateTime()
                },
                new Product
                {
                    ProductID = 103,
                    Code = "8A5D5A",
                    Name = "Draft Manager 2.0",
                    YearlyPrice = 15.99,
                    ReleaseDate = new DateTime()
                }
                );
            modelBuilder.Entity<Technician>().HasData(
                new Technician
                {
                    TechnicianID = 1001,
                    Name = "James Harvey",
                    Email = "James.Harvey@sportsprosoftware.com",
                    Phone = "419-255-2592"
                },
                new Technician
                {
                    TechnicianID = 1002,
                    Name = "Jessica Dickinson",
                    Email = "Jessicas.Dickinson@sportsprosoftware.com",
                    Phone = "647-258-1234"
                },
                new Technician
                {
                    TechnicianID = 1003,
                    Name = "Ana Smith",
                    Email = "Ana.Smith@sportsprosoftware.com",
                    Phone = "416-592-5533"
                });
            modelBuilder.Entity<Incident>().HasData(
                new Incident
                {
                    IncidentId=90001,
                    CustomerId=1,
                    ProductId=101,
                    Title="Error launching program",
                    Description="Program fails with 501 error, unable to open database",
                    TechnicianId = 1001,
                    DateOpened=new DateTime(),
                    DateClosed=new DateTime()
                },
                 new Incident
                 {
                     IncidentId = 90002,
                     CustomerId = 2,
                     ProductId = 103,
                     Title = "Unable to add new request",
                     Description = "Webpage shows system error, please try again",
                     TechnicianId = 1002,
                     DateOpened = new DateTime(),
                     DateClosed = new DateTime()
                 });
            modelBuilder.Entity<CustomerProduct>().HasData(
                new CustomerProduct
                {
                    CustomerID = 1,
                    ProductID = 101

                }); 
                        modelBuilder.Entity<CustomerProduct>()
                .HasKey(cp => new { cp.CustomerID, cp.ProductID });
            modelBuilder.Entity<CustomerProduct>()
                .HasOne(cp => cp.Customer)
                .WithMany(cp => cp.CustomerProduct)
                .HasForeignKey(cp => cp.CustomerID);
            modelBuilder.Entity<CustomerProduct>()
                .HasOne(cp => cp.Product)
                .WithMany(cp => cp.CustomerProduct)
                .HasForeignKey(cp => cp.ProductID);

        }

        
    }
}
