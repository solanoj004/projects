﻿namespace Toronto_Boys.Models
{
    public class CustomerProduct
    {
         public int CustomerID { get; set; }
         public Customer? Customer { get; set; }
         public int ProductID { get; set; }
         public Product? Product { get; set; }

    }
}