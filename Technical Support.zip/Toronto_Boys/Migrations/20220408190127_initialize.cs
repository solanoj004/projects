﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GBCSporting_Toronto_Boys.Migrations
{
    public partial class initialize : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Country",
                columns: table => new
                {
                    CountryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Country", x => x.CountryId);
                });

            migrationBuilder.CreateTable(
                name: "Customer",
                columns: table => new
                {
                    CustomerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Address = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    City = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    State = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PostalCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CountryId = table.Column<int>(type: "int", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer", x => x.CustomerID);
                });

            migrationBuilder.CreateTable(
                name: "Product",
                columns: table => new
                {
                    ProductID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    YearlyPrice = table.Column<double>(type: "float", nullable: false),
                    ReleaseDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Product", x => x.ProductID);
                });

            migrationBuilder.CreateTable(
                name: "Technician",
                columns: table => new
                {
                    TechnicianID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Technician", x => x.TechnicianID);
                });

            migrationBuilder.CreateTable(
                name: "CustomerProducts",
                columns: table => new
                {
                    CustomerID = table.Column<int>(type: "int", nullable: false),
                    ProductID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerProducts", x => new { x.CustomerID, x.ProductID });
                    table.ForeignKey(
                        name: "FK_CustomerProducts_Customer_CustomerID",
                        column: x => x.CustomerID,
                        principalTable: "Customer",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CustomerProducts_Product_ProductID",
                        column: x => x.ProductID,
                        principalTable: "Product",
                        principalColumn: "ProductID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Incident",
                columns: table => new
                {
                    IncidentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    TechnicianId = table.Column<int>(type: "int", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateOpened = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateClosed = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Incident", x => x.IncidentId);
                    table.ForeignKey(
                        name: "FK_Incident_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customer",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Incident_Product_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "ProductID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Incident_Technician_TechnicianId",
                        column: x => x.TechnicianId,
                        principalTable: "Technician",
                        principalColumn: "TechnicianID");
                });

            migrationBuilder.InsertData(
                table: "Country",
                columns: new[] { "CountryId", "Name" },
                values: new object[,]
                {
                    { 1, "Afghanistan" },
                    { 2, " Albania" },
                    { 3, " Algeria" },
                    { 4, " Andorra" },
                    { 5, " Angola" },
                    { 6, " Antigua & Deps" },
                    { 7, " Argentina" },
                    { 8, " Armenia" },
                    { 9, " Australia" },
                    { 10, " Austria" },
                    { 11, " Azerbaijan" },
                    { 12, " Bahamas" },
                    { 13, " Bahrain" },
                    { 14, " Bangladesh" },
                    { 15, " Barbados" },
                    { 16, " Belarus" },
                    { 17, " Belgium" },
                    { 18, " Belize" },
                    { 19, " Benin" },
                    { 20, " Bhutan" },
                    { 21, " Bolivia" },
                    { 22, " Bosnia Herzegovina" },
                    { 23, " Botswana" },
                    { 24, " Brazil" },
                    { 25, " Brunei" },
                    { 26, " Bulgaria" },
                    { 27, "Burkina" },
                    { 28, "Canada" },
                    { 29, "India" },
                    { 30, "Philippines" },
                    { 31, "USA" },
                    { 32, "Vietnam" }
                });

            migrationBuilder.InsertData(
                table: "Customer",
                columns: new[] { "CustomerID", "Address", "City", "CountryId", "Email", "FirstName", "LastName", "Phone", "PostalCode", "State" },
                values: new object[,]
                {
                    { 1, "4029 Bathurst St", "Toronto", 1, "Ronak.Gala@georgebrown.ca", "Ronak", "Gala", "467-654-1234", "M2K 4A8", "Ontario" },
                    { 2, "100 Beverly St", "Toronto", 2, "Danny.Nygen@georgebrown.ca", "Danny", "Nygen", "616-214-1234", "M25 4d8", "Ontario" },
                    { 3, "15A Dixxe Road", "Scarborough", 3, "Jacob.Solano@georgebrown.ca", "Jacob", "Solano", "654-693-3258", "M16 3Bh", "Ontario" }
                });

            migrationBuilder.InsertData(
                table: "Product",
                columns: new[] { "ProductID", "Code", "Name", "ReleaseDate", "YearlyPrice" },
                values: new object[,]
                {
                    { 101, "ABC123", "1v1 League Tourney", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 4.9900000000000002 },
                    { 102, "567SGV", "Team Manager 1.0", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 7.9900000000000002 },
                    { 103, "8A5D5A", "Draft Manager 2.0", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 15.99 }
                });

            migrationBuilder.InsertData(
                table: "Technician",
                columns: new[] { "TechnicianID", "Email", "Name", "Phone" },
                values: new object[,]
                {
                    { 1001, "James.Harvey@sportsprosoftware.com", "James Harvey", "419-255-2592" },
                    { 1002, "Jessicas.Dickinson@sportsprosoftware.com", "Jessica Dickinson", "647-258-1234" },
                    { 1003, "Ana.Smith@sportsprosoftware.com", "Ana Smith", "416-592-5533" }
                });

            migrationBuilder.InsertData(
                table: "CustomerProducts",
                columns: new[] { "CustomerID", "ProductID" },
                values: new object[] { 1, 101 });

            migrationBuilder.InsertData(
                table: "Incident",
                columns: new[] { "IncidentId", "CustomerId", "DateClosed", "DateOpened", "Description", "ProductId", "TechnicianId", "Title" },
                values: new object[] { 90001, 1, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Program fails with 501 error, unable to open database", 101, 1001, "Error launching program" });

            migrationBuilder.InsertData(
                table: "Incident",
                columns: new[] { "IncidentId", "CustomerId", "DateClosed", "DateOpened", "Description", "ProductId", "TechnicianId", "Title" },
                values: new object[] { 90002, 2, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Webpage shows system error, please try again", 103, 1002, "Unable to add new request" });

            migrationBuilder.CreateIndex(
                name: "IX_CustomerProducts_ProductID",
                table: "CustomerProducts",
                column: "ProductID");

            migrationBuilder.CreateIndex(
                name: "IX_Incident_CustomerId",
                table: "Incident",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Incident_ProductId",
                table: "Incident",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Incident_TechnicianId",
                table: "Incident",
                column: "TechnicianId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Country");

            migrationBuilder.DropTable(
                name: "CustomerProducts");

            migrationBuilder.DropTable(
                name: "Incident");

            migrationBuilder.DropTable(
                name: "Customer");

            migrationBuilder.DropTable(
                name: "Product");

            migrationBuilder.DropTable(
                name: "Technician");
        }
    }
}
