﻿using Microsoft.AspNetCore.Mvc;
using Toronto_Boys.Models;

namespace GBCSporting_Toronto_Boys.Controllers
{
    public class TechIncidentController : Controller
    {
        private readonly MainContext _db;

        public TechIncidentController(MainContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var Technicians = _db.Technician.ToList();
            ViewBag.Technicians = Technicians;
            return View();
        }
        public IActionResult Detail(int? TechnicianID)
        {
            if(TechnicianID == null || TechnicianID == 0)
            {
                return NotFound();
            }
            var Incidents = _db.Incident.ToList();
            List<Incident> viewList = new List<Incident>();
            foreach( Incident i in Incidents)
            {
                if(i.TechnicianId == TechnicianID)
                {
                    i.Customer = _db.Customer.Find(i.CustomerId);
                    i.Product = _db.Product.Find(i.ProductId);
                    i.Technician = _db.Technician.Find(i.TechnicianId);
                    ViewBag.Name = i.Technician.Name;
                    viewList.Add(i);
                }
            }
            ViewBag.Incidents = viewList;
            ViewBag.Customers = _db.Customer.ToList();
            ViewBag.Products = _db.Product.ToList();

            return View(viewList);
        }
        // Get method for grabbing the customer information by the incidentID
        public IActionResult Edit(int? id)
        {
            var incidentFromDb = _db.Incident.Find(id);
            var Customer = _db.Customer.Find(incidentFromDb.CustomerId);
            var Products = _db.Product.Find(incidentFromDb.ProductId);
            var Technicians = _db.Technician.Find(incidentFromDb.TechnicianId);
            Incident i = new Incident
            {
                IncidentId = incidentFromDb.IncidentId,
                Customer = Customer,
                Product = Products,
                Technician = Technicians,
                CustomerId = incidentFromDb.CustomerId,
                ProductId = incidentFromDb.ProductId,
                TechnicianId = incidentFromDb.TechnicianId,
                Title = incidentFromDb.Title,
                DateOpened = incidentFromDb.DateOpened,
                DateClosed = incidentFromDb.DateClosed,
                Description = incidentFromDb.Description
            };
            return View(i);
        }
        // Post method for saving the edit of the incident
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Incident obj)
        {

            if (ModelState.IsValid)
            {
                if (obj.IncidentId != 0)
                {
                    _db.Incident.Update(obj);
                    _db.SaveChanges();
                    TempData["success"] = "  Incident " + obj.Title + " edited successfully";
                }
                return RedirectToAction("Index");
            }
            else
            {

                return NotFound();
            }

        }
    }
}
