﻿using Microsoft.AspNetCore.Mvc;
using Toronto_Boys.Models;

namespace Toronto_Boys.Controllers
{
    public class TechnicianController : Controller
    {
        private readonly MainContext _db;

        public TechnicianController(MainContext db)
        {
            _db = db;
        }
        // Method for viewing all the Technician in the database
        public IActionResult Index()
        {
            var technician = _db.Technician
                .OrderBy(m => m.TechnicianID)
                .ToList();
            return View(technician);
        }

        // Method for adding/creating a new Technician in the database
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("Edit", new Technician());
        }

        // Get method for grabbing the customer information by the technicianID
        public IActionResult Edit(int? id)
        {
            var technicianFromDb = _db.Technician.Find(id);
            ViewBag.Action = "Edit";
            return View(technicianFromDb);
        }
        // Post method for saving the edit of the Technician
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Technician obj)
        {

            if (ModelState.IsValid)
            {
                if (obj.TechnicianID == 0)
                {
                    _db.Technician.Add(obj);
                    _db.SaveChanges();
                    TempData["success"] = "  Technician " + obj.Name+" added successfully";
                }
                else
                {
                    _db.Technician.Update(obj);
                    _db.SaveChanges();
                    TempData["success"] = "  Technician "+obj.Name +" edited successfully";
                }
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.Action = (obj.TechnicianID == 0) ? "Add" : "Edit";
                return View(obj);
            }

        }
        // Get method for deleting a customer by the technicianID
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var technician = _db.Technician.Find(id);
            if (technician == null)
            {
                return NotFound();
            }
            return View(technician);
        }
        // Post method for the actual deletion of the customer in the database by technicianID
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var obj = _db.Technician.Find(id);
            if (obj == null)
            {
                return NotFound();
            }
            _db.Technician.Remove(obj);
            _db.SaveChanges();
            TempData["success"] = "  Technician deleted successfully";
            return RedirectToAction("Index");
        }
    }
}
