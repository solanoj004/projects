﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Toronto_Boys.Models;

namespace Toronto_Boys.Controllers
{
    public class ProductController : Controller
    {
        private readonly MainContext _db;

        public ProductController(MainContext db)
        {
            _db = db;
        }
        // Method for viewing all the Product in the database
        public IActionResult Index()
        {
            var product=_db.Product
                .OrderBy(m=> m.ProductID)
                .ToList();
            return View(product);
        }
        // Method for adding/creating a new Product in the database
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("Edit",new Product());
        }


        // Get method for grabbing the customer information by the productID
        public IActionResult Edit(int? id)
        {
            var productFromDb = _db.Product.Find(id);
            ViewBag.Action = "Edit";
            return View(productFromDb);
        }
        // Post method for saving the edit of the product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Product obj)
        {
            
            if (ModelState.IsValid)
            {
                if (obj.ProductID == 0)
                {
                    _db.Product.Add(obj);
                    _db.SaveChanges(); 
                    TempData["success"] = "  Product " + obj.Name + " created successfully";
                }
                else
                {
                    _db.Product.Update(obj);
                    _db.SaveChanges();
                    TempData["success"] = "  Product " + obj.Name+" edited successfully";

                }
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.Action = (obj.ProductID == 0) ? "Add" : "Edit";
                return View(obj);
            }
            
        }
        // Get method for deleting a customer by the productID
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var productFromDb = _db.Product.Find(id);
            if (productFromDb == null)
            {
                return NotFound();
            }
            return View(productFromDb);
        }
        // Post method for the actual deletion of the customer in the database by productID
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var obj = _db.Product.Find(id);
            if (obj == null)
            {
                return NotFound();
            }
            _db.Product.Remove(obj);
            _db.SaveChanges();
            TempData["success"] = "  Product deleted successfully";
            return RedirectToAction("Index");
        }
    }
}
