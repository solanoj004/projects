﻿using Toronto_Boys.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Toronto_Boys.Models;



namespace Toronto_Boys.Controllers
{
    public class IncidentController : Controller
    {
        private readonly MainContext _db;

        public IncidentController(MainContext db)
        {
            _db = db;
        }
        // Method for grabbing information from Product, Technician, Customer and incident information from DB to view in incident page
       
        public IActionResult Index(string Filter ="all" )
        {
            var incidents = _db.Incident
                .Include(m => m.Customer)
                .Include(m => m.Product)
                .Include(m => m.Technician)
                .OrderBy(m => m.IncidentId)
                .ToList();
            List<Incident> incidentList = new List<Incident>();
            String filter;
            ViewBag.Active = Filter;
            if(Filter == "unassigned")
            {
                filter = "unassigned";
                foreach(Incident i in incidents)
                {
                    if(i.TechnicianId == 0 || i.TechnicianId == null)
                    {
                        incidentList.Add(i);
                    }
                }
            }
            else if (Filter == "open")
            {
                filter = "open";
                foreach (Incident i in incidents)
                {
                    if (i.DateClosed == null)
                    {
                        incidentList.Add(i);
                    }
                }
            }
            else
            {
                filter = "all";
                foreach (Incident i in incidents)
                {
                     incidentList.Add(i);
                }
            }
            var IncidentManagerViewModel = new IncidentManagerViewModel
            {
                incidents = incidentList,
                Filter = filter

            };
            return View("Index", IncidentManagerViewModel);
        }

        // Method for adding/creating a new incident in the database
        public IActionResult Add()
        {
            var OperationIncident = new OperationIncident()
            {
                customers = _db.Customer.OrderBy(c => c.CustomerID).ToList(),
                products = _db.Product.OrderBy(p => p.ProductID).ToList(),
                technicians = _db.Technician.OrderBy(T => T.TechnicianID).ToList(),
                incident = new Incident(),
                operation = "add"
            }; 
            return View("Edit", OperationIncident);
        }


        // Get method for grabbing the customer information by the incidentID
        public IActionResult Edit(int? id)
        {
            
            OperationIncident operationIncident = new OperationIncident()
            {
                customers = _db.Customer.OrderBy(c => c.CustomerID).ToList(),
                products = _db.Product.OrderBy(p => p.ProductID).ToList(),
                technicians = _db.Technician.OrderBy(T => T.TechnicianID).ToList(),
                incident = _db.Incident.Find(id),
                operation = "edit"
            };
            return View("Edit", operationIncident);
        }
        // Post method for saving the edit of the incident
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(OperationIncident obj)
        {

            
                if (obj.operation == "add")
                {
                    var incidentoAdd = new Incident();
                    incidentoAdd.IncidentId = obj.incident.IncidentId;
                    incidentoAdd.CustomerId = obj.incident.CustomerId;
                    incidentoAdd.ProductId = obj.incident.ProductId;
                    incidentoAdd.Title = obj.incident.Title;
                    incidentoAdd.TechnicianId = obj.incident.TechnicianId;
                    incidentoAdd.Description = obj.incident.Description;
                    incidentoAdd.DateClosed = obj.incident.DateClosed;
                    incidentoAdd.DateOpened = obj.incident.DateOpened;
                    _db.Incident.Add(incidentoAdd);
                    _db.SaveChanges();
                    TempData["success"] = "  Incident "+ obj.incident.Title +" added successfully";
                }
                else
                {
                    var incidentToEdit = _db.Incident.FirstOrDefault(x => x.IncidentId == obj.incident.IncidentId);
                    incidentToEdit.IncidentId = obj.incident.IncidentId;
                    incidentToEdit.CustomerId = obj.incident.CustomerId;
                    incidentToEdit.ProductId = obj.incident.ProductId;
                    incidentToEdit.Title = obj.incident.Title;
                    incidentToEdit.TechnicianId = obj.incident.TechnicianId;
                    incidentToEdit.Description = obj.incident.Description;
                    incidentToEdit.DateClosed = obj.incident.DateClosed;
                    incidentToEdit.DateOpened = obj.incident.DateOpened;
                    _db.Incident.Update(incidentToEdit);
                    _db.SaveChanges();
                    TempData["success"] = "  Incident "+obj.incident.Title +" edited successfully";
                }
                return RedirectToAction("Index");
            
            

        }
        // Get method for deleting a customer by the incidentID
        public IActionResult Delete(int? id)
        {

            if (id == null || id == 0)
            {
                return NotFound();
            }
            var incident = _db.Incident.Find(id);
            if (incident == null)
            {
                return NotFound();
            }
            var customer = _db.Customer
               .OrderBy(m => m.CustomerID)
               .ToList();

            var cust = _db.Customer.Find(incident.CustomerId);
            ViewBag.cs1 = cust.FullName.ToString();
            return View(incident);
        }
        // Post method for the actual deletion of the customer in the database by incidentID
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var obj = _db.Incident.Find(id);
            if (obj == null)
            {
                return NotFound();
            }
            _db.Incident.Remove(obj);
            _db.SaveChanges();
            TempData["success"] = "  Incident deleted successfully";
            return RedirectToAction("Index");
        }
    }
}
