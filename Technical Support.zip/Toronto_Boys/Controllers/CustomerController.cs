﻿using Microsoft.AspNetCore.Mvc;
using Toronto_Boys.Models;
using System.Globalization;


namespace Toronto_Boys.Controllers
{
    public class CustomerController : Controller
    {
        private readonly MainContext _db;

        public CustomerController(MainContext db)
        {
            _db = db;
        }
        // Method for viewing all the customers in the database
        public IActionResult Index()
        {
            var customer = _db.Customer
                .OrderBy(m => m.CustomerID)
                .ToList();
            return View(customer);
        }

        // Method for adding/creating a new customer in the database
        public IActionResult Add()
        {
            ViewBag.Country = _db.Country;
            ViewBag.Action = "Add";
            return View("Edit", new Customer());
        }

        // Get method for grabbing the customer information by the customerID
        public IActionResult Edit(int? id)
        {
            var customerFromDb = _db.Customer.Find(id);
            ViewBag.Country = _db.Country;
            ViewBag.Action = "Edit";
            return View(customerFromDb);
        }
        // Post method for saving the edit of the customer 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Customer obj)
        {
            ViewBag.Country = _db.Country;
            
            if (obj.CustomerID == 0)
            {
                var customers = _db.Customer.ToList();
                List<string> emailList = new List<string>();
                foreach (Customer c in customers)
                {
                    emailList.Add(c.Email);
                }
                foreach (string e in emailList)
                {
                    if (obj.Email == e)
                    {
                        TempData["success"] = " Email already exists";
                        return View("Edit", obj);
                    }
                }
                _db.Customer.Add(obj);
                _db.SaveChanges();
                TempData["success"] = "  Customer "+ obj.FirstName +" added successfully";
                return RedirectToAction("Index");
            }
            else
            {
                var customers = _db.Customer.ToList();
                List<string> emailList = new List<string>();
                foreach (Customer c in customers)
                {
                    emailList.Add(c.Email);
                }
                foreach (string e in emailList)
                {
                    if (obj.Email == e)
                    {
                        TempData["success"] = " Email already exists";
                        return View("Edit", obj);
                    }
                }
                _db.Customer.Update(obj);
                _db.SaveChanges();
                TempData["success"] = "  Customer "+ obj.FirstName+" edited successfully";
                return RedirectToAction("Index");
            } 
            ViewBag.Action = (obj.CustomerID == 0) ? "Add" : "Edit";
            return View(obj);
        }
        // Get method for deleting a customer by the customerID
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var customer = _db.Customer.Find(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }
        // Post method for the actual deletion of the customer in the database by customerID
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var obj = _db.Customer.Find(id);
            if (obj == null)
            {
                return NotFound();
            }
            _db.Customer.Remove(obj);
            _db.SaveChanges();
            TempData["success"] = "  Customer deleted successfully";
            return RedirectToAction("Index");
        }

     
       
    }
}
