﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Toronto_Boys.Models;

namespace Toronto_Boys.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [Route("/")]
        // Method for viewing the Homepage
        public IActionResult Index()
        {
            return View();
        }
        // Method for viewing the Product page
        public IActionResult Product()
        {
            return View();
        }
        // Method for viewing the Technician page
        public IActionResult Technician()
        {
            return View();
        }
        // Method for viewing the Customer page
        public IActionResult Customer()
        {
            return View();
        }
        // Method for viewing the Incident page
        public IActionResult Incident()
        {
            return View();
        }

        // Method for viewing the About page
        [Route("About")]
        public IActionResult About()
        {
            return View();
        }

        // Method for viewing the Registration page
        public IActionResult Registration()
        {
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}