﻿using Microsoft.AspNetCore.Mvc;
using Toronto_Boys.Models;

namespace GBCSporting_Toronto_Boys.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly MainContext _db;

        public RegistrationController(MainContext db)
        {
            _db = db;
        }
        public IActionResult GetCustmer()
        {
            var Customers = _db.Customer.ToList();
            ViewBag.Customers = Customers;
            return View();
        }
        public IActionResult Index(int? CustomerID)
        {

            if (CustomerID == null || CustomerID == 0)
            {
                return NotFound();
            }
            var customersProducts = _db.CustomerProducts.ToList();
            var currentCustomer = _db.Customer.Find(CustomerID);
            ViewBag.Name = currentCustomer.FullName;
            ViewBag.CustPro = customersProducts;
            ViewBag.Customers = _db.Customer.ToList();
            ViewBag.Products = _db.Product.ToList();

            return View();

        }
        public IActionResult add(int CustomerId, int ProductID)
        {
            ViewBag.Customers = _db.Customer.ToList();
            ViewBag.Products = _db.Product.ToList();
            var customer = _db.Customer.Find(CustomerId);
            var product = _db.Product.Find(ProductID);
            var CustPro = _db.CustomerProducts.ToList();
            foreach(CustomerProduct custPro in CustPro)
                if(custPro.ProductID == ProductID)
                {
                TempData["success"] = "Product already added";
                return View("GetCustmer");
                }
            var customerProduct = new CustomerProduct
            {
                CustomerID = CustomerId,
                ProductID = ProductID,
                Customer = customer,
                Product = product
            };
            _db.CustomerProducts.Add(customerProduct);
            _db.SaveChanges();
            TempData["success"] = "Product Added successfully";
            return View("GetCustmer");
        }
        public IActionResult delete(int pid, int cid)
        {
            ViewBag.Customers = _db.Customer.ToList();
            ViewBag.Products = _db.Product.ToList();
            var customer = _db.Customer.Find(cid);
            var product = _db.Product.Find(pid);
            var customerProduct = new CustomerProduct
            {
                CustomerID = cid,
                ProductID = pid,
                Customer = customer,
                Product = product
            };
            _db.CustomerProducts.Remove(customerProduct);
            _db.SaveChanges();
            TempData["success"] = "Product Deleted";
            return View("GetCustmer");
        }

    }
}
