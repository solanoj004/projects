﻿using Toronto_Boys.Models;

namespace Toronto_Boys.ViewModels
{
    public class IncidentManagerViewModel
    {
        public List<Incident> incidents { get; set; }
        public string Filter { get; set; }
    }
}
