﻿using Toronto_Boys.Models;
namespace Toronto_Boys.ViewModels
{
    public class OperationIncident
    {
        public List<Customer> customers { get; set; }
        public List<Product> products { get; set; }
        public List<Technician> technicians { get; set; }
        public Incident incident { get; set; }
        public string operation { get; set; }
    }
}
