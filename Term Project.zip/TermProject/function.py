# Jacob Solano
# Student ID: 101348583
import re


def validate_year():
    while True:
        user_input = int(input("Enter year: "))
        if user_input:
            if 2019 <= user_input <= 2022:
                return user_input
            else:
                print("Please only enter between 2019 and 2022.")
                continue
        else:
            print("Please only enter between 2019 and 2022. ")
            continue


def validate_month():
    while True:
        user_input = int(input("Enter month: "))
        if user_input:
            if 1 <= user_input <= 12:
                return user_input
            else:
                print("Please only enter between 1 and 12.")
                continue
        else:
            print("Please only enter between 1 and 12. ")
            continue


def validate_cost(cost_type):
    while True:
        try:
            user_input = float(input(f"Enter {cost_type} cost: "))
            return user_input
        except ValueError:
            print("Please enter a valid float number.")
            continue


def confirm_y_or_n():
    while True:
        user_input = input("Update this row? Type Y or N: ")
        user_input = user_input.lower()
        if user_input:
            if re.match("^(?:y|n)$", user_input):
                return user_input
            else:
                print("Please input only Y or N")
                continue
        else:
            print("Please enter your input. ")
            continue
