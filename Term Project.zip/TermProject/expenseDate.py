# Jacob Solano
# Student ID: 101348583
class ExpenseDate:
    def __init__(self, p_month, p_year):
        self.__month = p_month
        self.__year = p_year

    @property
    def month(self):
        return self.__month

    @month.setter
    def month(self, value):
        self.__month = value

    @property
    def year(self):
        return self.__year

    @year.setter
    def year(self, value):
        self.__year = value

