# Jacob Solano
# Student ID: 101348583
class Expense:
    def __init__(self, p_food, p_clothing, p_entertainment, p_rent):
        self.__food = p_food
        self.__clothing = p_clothing
        self.__entertainment = p_entertainment
        self.__rent = p_rent

    @property
    def food(self):
        return self.__food

    @food.setter
    def food(self, value):
        self.__food = value

    @property
    def clothing(self):
        return self.__clothing

    @clothing.setter
    def clothing(self, value):
        self.__clothing = value

    @property
    def entertainment(self):
        return self.__entertainment

    @entertainment.setter
    def entertainment(self, value):
        self.__entertainment = value

    @property
    def rent(self):
        return self.__rent

    @rent.setter
    def rent(self, value):
        self.__rent = value

    def amount(self):
        return self.__food + self.__clothing + self.__entertainment + self.__rent
