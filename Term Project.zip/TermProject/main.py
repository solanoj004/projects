# Jacob Solano
# Student ID: 101348583
import sqlite3
from expense import Expense
from expenseDate import ExpenseDate
import function
import sqlfunction
from sqlite3 import Error


# Creates connection to the database
def create_connection(db_file):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        print(sqlite3.version)
    except Error as e:
        print(e)
    return conn


if __name__ == '__main__':
    conn = create_connection(r"expenseTracker.db")

cursor = conn.cursor()

# Create tables with names 2019, 2020, 2021, and 2022
cursor.execute("CREATE TABLE IF NOT EXISTS Year_2019("
               "ExpenseID INTEGER PRIMARY KEY,"
               "FoodCost FLOAT,"
               "ClothingCost FLOAT,"
               "EnterCost FLOAT,"
               "RentCost FLOAT,"
               "Amount FLOAT,"
               "Month INT)")

cursor.execute("CREATE TABLE IF NOT EXISTS Year_2020("
               "ExpenseID INTEGER PRIMARY KEY,"
               "FoodCost FLOAT,"
               "ClothingCost FLOAT,"
               "EnterCost FLOAT,"
               "RentCost FLOAT,"
               "Amount FLOAT,"
               "Month INT)")

cursor.execute("CREATE TABLE IF NOT EXISTS Year_2021("
               "ExpenseID INTEGER PRIMARY KEY,"
               "FoodCost FLOAT,"
               "ClothingCost FLOAT,"
               "EnterCost FLOAT,"
               "RentCost FLOAT,"
               "Amount, FLOAT,"
               "Month INT)")

cursor.execute("CREATE TABLE IF NOT EXISTS Year_2022("
               "ExpenseID INTEGER PRIMARY KEY,"
               "FoodCost FLOAT,"
               "ClothingCost FLOAT,"
               "EnterCost FLOAT,"
               "RentCost FLOAT,"
               "Amount FLOAT,"
               "Month INT)")


# Menu
def menu():
    print("--------------------------------------------------")
    print("| 1. Add Expense                            |")
    print("| 2. Update Expense                         |")
    print("| 3. Delete Expense                         |")
    print("| 4. Print Specific Expense                 |")
    print("| 5. Print Annual Expense                   |")
    print("| 6. Quit                                   |")
    print("--------------------------------------------------")

    choice = int(input("Enter your choice: "))
    if choice == 1:
        add_expense()
    elif choice == 2:
        update_expense()
    elif choice == 3:
        delete_expense()
    elif choice == 4:
        print_month_expense()
    elif choice == 5:
        print_all_expense()
    elif choice == 6:
        print("Thank you for using this application.")
        quit()
    else:
        print("Invalid choice.")
        menu()


# Add expense function
def add_expense():
    year = function.validate_year()
    month = function.validate_month()

    expenseDate = ExpenseDate(month, year)

    # Query for selecting a row with specific month from a specified table name
    query = f"SELECT * FROM Year_{expenseDate.year} WHERE Month={expenseDate.month}"
    cursor.execute(query)
    row = cursor.fetchone()
    # Checks if row with the specific month and year is empty
    # If row is empty, add expense
    if row is None:
        food = function.validate_cost("food")
        clothing = function.validate_cost("clothing")
        entertainment = function.validate_cost("entertainment")
        rent = function.validate_cost("rent")

        expense = Expense(food, clothing, entertainment, rent)
        amount = expense.amount()

        # Insert values of FoodCost, ClothingCost, EnterCost, RentCost, Amount, and Month to Row
        query1 = f"INSERT INTO Year_{expenseDate.year} (FoodCost, ClothingCost, EnterCost, RentCost, " \
                 f" Amount, Month) VALUES ({expense.food}, " \
                 f"{expense.clothing}, {expense.entertainment}, {expense.rent}, {amount}, {expenseDate.month})"
        cursor.execute(query1)
        conn.commit()
        print("Successfully inputted data.")
        menu()
    # Print out message that there is a record for that year and month
    else:
        print("--------------------------------------------------------------")
        print("ExpenseID, FoodCost, ClothingCost, EnterCost, RentCost, Amount, Month")
        print(row)
        print("There is already a record for that month and year.")
        menu()


# Update Expense function
def update_expense():
    year = function.validate_year()
    month = function.validate_month()

    expenseDate = ExpenseDate(month, year)

    # Query for selecting a row with specific month from a specified table name
    query = f"SELECT * FROM Year_{expenseDate.year} WHERE Month={expenseDate.month}"
    cursor.execute(query)
    row = cursor.fetchone()

    # Checks if row with the specific month and year is empty
    # If row has values, prompt user if they want to update this row
    if row is not None:
        print("ExpenseID, FoodCost, ClothingCost, EnterCost, RentCost, Amount, Month")
        print(row)
        choice = function.confirm_y_or_n()
        if choice == "y":
            food = function.validate_cost("food")
            clothing = function.validate_cost("clothing")
            entertainment = function.validate_cost("entertainment")
            rent = function.validate_cost("rent")

            expense = Expense(food, clothing, entertainment, rent)
            amount = expense.amount()
            # Query for updating row
            query1 = f"UPDATE Year_{expenseDate.year}" \
                     f" SET FoodCost = {expense.food}, " \
                     f" ClothingCost={expense.clothing}, " \
                     f" EnterCost={expense.entertainment}, " \
                     f" RentCost={expense.rent}," \
                     f" Amount={amount}" \
                     f" WHERE Month={expenseDate.month};"
            cursor.execute(query1)
            conn.commit()
            print("Successfully updated row.")
            menu()
        else:
            print("Cancelled updating row.")
            input("Going back to main menu (Press enter to continue)")
            menu()
    # Row does not have data
    else:
        print("Record does not exist for that date")
        menu()


# Delete Expense function
def delete_expense():
    print("This function is not implemented.")
    menu()


# Print an expense with a specified year and month
def print_month_expense():
    year = function.validate_year()
    month = function.validate_month()

    expenseDate = ExpenseDate(month, year)

    create_file(expenseDate.year)
    # Query for selecting a row with specific month from a specified table name
    query = f"SELECT * FROM Year_{expenseDate.year} WHERE Month={expenseDate.month}"
    cursor.execute(query)
    row = cursor.fetchone()

    # Checks if row with the specific month and year is empty
    # If row has values, prompt user if they want to update this row
    if row is not None:
        # Prints the expenses for the specified month and year.
        print(f"\nThe expenses for {month} {year}")
        print("----------------------")
        print(f"Food Cost: {row[1]} --", f"{(row[1] / row[5] * 100):.2f}", "% of Total Expense")
        print(f"Clothing Cost: {row[2]} --", f"{(row[2] / row[5] * 100):.2f}", "% of Total Expense")
        print(f"Entertainment Cost: {row[3]} -- ", f"{(row[3] / row[5] * 100):.2f}", "% of Total Expense")
        print(f"Rent Cost: {row[4]} -- ", f"{(row[4] / row[5] * 100):.2f}", "% of Total Expense")
        print(f"Total Expenses: {row[5]}")

        annual_average = calculate_annual(year)[4]
        print(f"The annual average is: {annual_average}")
        if row[5] < annual_average:
            print("This month's is less than the average.")
        if row[5] == annual_average:
            print("This month's is equal to the average.")
        else:
            print("This month's is more than the average.")
    else:
        print("That record does not exist.")
    menu()


# Print all expenses from specified year
def print_all_expense():
    year = function.validate_year()

    # Clears all data in the text file
    expense_file = open(f"{year}.txt", "r+")
    expense_file.truncate()
    expense_file.close()

    # Query for selecting all rows from specified table name
    query = f"SELECT * FROM Year_{year}"
    cursor.execute(query)
    rows = cursor.fetchall()

    # This for loop writes to a text file the monthly expenses with all categories
    for row in rows:
        food = row[1]
        clothing = row[2]
        entertainment = row[3]
        rent = row[4]
        amount = row[5]
        month = row[6]
        write_to_file(year, food, clothing, entertainment, rent, amount, month)

    # A tuple that contains the average of all expenses from all categories from the year
    average_category_tuple = calculate_annual(year)
    # Variables than contains the averages of the expenses categories from the tuple
    food_average = average_category_tuple[0]
    clothing_average = average_category_tuple[1]
    enter_average = average_category_tuple[2]
    rent_average = average_category_tuple[3]
    amount_average = average_category_tuple[4]

    # Writes to the end of the file the averages of expense categories
    write_to_file_average(year, food_average, clothing_average, enter_average, rent_average, amount_average)

    # Prints all lines from the file
    expense_file = open(f"{year}.txt", "r+")
    lines = expense_file.readlines()
    for line in lines:
        print(line)
    expense_file.close()
    menu()


# Creates a file named with the specified year
def create_file(year):
    try:
        expenseTxt = open(f"{year}.txt", "r+")
    except FileNotFoundError:
        print("No file is found! We will make one for you. Enter year again!")
        expenseTxt = open(f"{year}.txt", "w")
        menu()
    except OSError:
        print("File found - error reading file!")
    except Error:
        print("An unexpected error occurred!")


# Function for returning a tuple that contains average from expense categories
def calculate_annual(year):
    query1 = f"SELECT AVG(FoodCost) FROM Year_{year}"
    query2 = f"SELECT AVG(ClothingCost) FROM Year_{year}"
    query3 = f"SELECT AVG(EnterCost) FROM Year_{year}"
    query4 = f"SELECT AVG(RentCost) FROM Year_{year}"
    query5 = f"SELECT AVG(Amount) FROM Year_{year}"

    cursor.execute(query1)
    food_average = cursor.fetchone()[0]

    cursor.execute(query2)
    clothing_average = cursor.fetchone()[0]

    cursor.execute(query3)
    entertainment_average = cursor.fetchone()[0]

    cursor.execute(query4)
    rent_average = cursor.fetchone()[0]

    cursor.execute(query5)
    amount_average = cursor.fetchone()[0]

    return food_average, clothing_average, entertainment_average, rent_average, amount_average


# Function for writing to file the monthly expense in a nice format
def write_to_file(year, food, clothing, entertainment, rent, amount, month):
    create_file(year)

    with open(f"{year}.txt", "a") as expense_file:
        expense_file.write(f"\nThis is the expense for {month} {year}")
        expense_file.write(f"\n--------------------------------")
        expense_file.write(f"\nFood Cost: {food}")
        expense_file.write(f"\nClothing Cost: {clothing}")
        expense_file.write(f"\nEntertainment Cost: {entertainment}")
        expense_file.write(f"\nRent Cost: {rent}")
        expense_file.write(f"\nTotal Expense Cost: {amount}")
        expense_file.write(f"\nMonth Cost: {month}")
        expense_file.close()


# Function for writing to file the averages of expense categories in a nice format
def write_to_file_average(year, food_average, clothing_average, enter_average, rent_average, expense_average):
    with open(f"{year}.txt", "a") as expense_file:
        expense_file.write(f"\nThe annual food average cost is: {food_average}")
        expense_file.write(f"\nThe annual clothing average cost is: {clothing_average}")
        expense_file.write(f"\nThe annual entertainment average cost is: {enter_average}")
        expense_file.write(f"\nThe annual rent average cost is: {rent_average}")
        expense_file.write(f"\nThe total expense average is: {expense_average}")


def welcome_message():
    print("--------------------------------------------------")
    print("|   Welcome.                                   |")
    print("|   This application will track                |")
    print("|   your expenses from year 2019-2022          |")
    print("--------------------------------------------------")
    input("Press enter to continue")


welcome_message()
menu()
